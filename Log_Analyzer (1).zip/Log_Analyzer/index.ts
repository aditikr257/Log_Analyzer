// Import required modules
import * as fs from 'fs';
import * as readlineSync from 'readline-sync';

// Define interfaces for log entry, API call count, and API response
interface LogEntry {
  timestamp: string;
  endpoint: string;
  statusCode: number;
}

interface ApiCallCount {
  [key: string]: number;
}

interface ApiResponse {
  statusCode: number;
  count: number;
}

// Read the log file and parse log data into an array of LogEntry objects
function readLogFile(filePath: string): LogEntry[] {
  const logData = fs.readFileSync(filePath, 'utf8');
  const lines = logData.split('\n');
  const logEntries: LogEntry[] = [];

  for (const line of lines) {
    try {
      const parts = line.split(' ');
      const timestamp = parts[0] + ' ' + parts[1];
      const statusCode = parseInt(parts[parts.length - 2]);
      const endpoint = parts[7];
      logEntries.push({ timestamp, endpoint, statusCode });
    } catch (error) {
      // Ignore invalid log entries
    }
  }

  return logEntries;
}

// Count the number of calls made to each API endpoint
function countEndpointCalls(logEntries: LogEntry[]): ApiCallCount {
  const endpointCalls: ApiCallCount = {};

  for (const entry of logEntries) {
    const { endpoint } = entry;
    if (!endpointCalls[endpoint]) {
      endpointCalls[endpoint] = 0;
    }
    endpointCalls[endpoint]++;
  }

  return endpointCalls;
}

// Count the number of API calls made per minute
function countApiCallsPerMinute(logEntries: LogEntry[]): ApiCallCount {
  const apiCallsPerMinute: ApiCallCount = {};

  for (const entry of logEntries) {
    const { timestamp } = entry;
    const minute = timestamp.split(':')[0];
    if (!apiCallsPerMinute[minute]) {
      apiCallsPerMinute[minute] = 0;
    }
    apiCallsPerMinute[minute]++;
  }

  return apiCallsPerMinute;
}

// Count the number of API calls for specific status codes (200, 500, 404, 304)
function countApiCallsByStatusCode(logEntries: LogEntry[]): ApiResponse[] {
  const allowedStatusCodes = [200, 500, 404, 304];
  const apiCallsByStatusCode: ApiCallCount = {};

  for (const entry of logEntries) {
    const { statusCode } = entry;
    if (allowedStatusCodes.includes(statusCode)) {
      if (!apiCallsByStatusCode[statusCode]) {
        apiCallsByStatusCode[statusCode] = 0;
      }
      apiCallsByStatusCode[statusCode]++;
    }
  }

  const apiCallsByStatusCodeList: ApiResponse[] = [];
  for (const statusCode in apiCallsByStatusCode) {
    apiCallsByStatusCodeList.push({ statusCode: parseInt(statusCode), count: apiCallsByStatusCode[statusCode] });
  }

  return apiCallsByStatusCodeList;
}

// Print the formatted table with API response data
function printFormattedTable(data: ApiResponse[]) {
  console.log('┌──────────────┬────────────┬───────┐');
  console.log('|   (index)    | statusCode | count |');
  console.log('├──────────────┼────────────┼───────┤');
  data.forEach((entry) => {
    const statusText = entry.statusCode === 200 ? 'OK' : entry.statusCode === 500 ? 'Server Error' : entry.statusCode === 404 ? 'Not found' : entry.statusCode === 304 ? 'Not changed' : '';
    console.log(`│ ${statusText.padEnd(12)} │     ${entry.statusCode}      │  ${entry.count.toString().padStart(4)}  │`);
  });
  console.log('└──────────────┴────────────┴───────┘');
}

// Main function that orchestrates the log analysis
function main() {
  const filePath = readlineSync.question('Enter the path to the log file: ');

  try {
    // Read log data from the file
    const logEntries = readLogFile(filePath);

    // Count endpoint calls and display in a table
    const endpointCalls = countEndpointCalls(logEntries);
    console.log('Endpoint Call Counts:');
    console.table(endpointCalls);

    // Count API calls per minute and display in a table
    const apiCallsPerMinute = countApiCallsPerMinute(logEntries);
    console.log('\nAPI Calls Per Minute:');
    console.table(apiCallsPerMinute);

    // Count API calls by status code and display in a formatted table
    const apiCallsByStatusCode = countApiCallsByStatusCode(logEntries);
    console.log('\nAPI Calls by Status Code:');
    printFormattedTable(apiCallsByStatusCode);
  } catch (error) {
    console.error('Error occurred:', error.message);
  }
}

// Call the main function to start the log analysis
main();
