# Log Analyzer

This Node.js script is a log analyzer that reads log data from a file, performs various data calculations, and presents the results in a formatted table. It helps analyze the log data for different API endpoints and status codes.

## Installation and Setup

1. Make sure you have Node.js installed on your system.

2. Clone or download this repository.

3. Navigate to the project directory in the terminal.

4. Install the required dependencies using the following command:

   ```
   npm install
   ```


## How to Use

To accomplish the task of log digestion in NodeJS, we will follow these steps:

* Create a CLI application in TypeScript.

Here's a TypeScript implementation to achieve this task:

1. Set up the project:
   Create a new folder for the project and initialize a NodeJS TypeScript project with `npm init -y`. 
   Then install the required packages:
    `npm install readline-sync fs`

2. Instructions to Run the Code:
    - Make sure you have Node.js installed on your system.
    - Copy the above code and save it into a file named index.ts inside your project folder.
    - Open a terminal window, navigate to your project folder, and run the following command to    
      compile TypeScript:
      `npx tsc index.ts`
      This will generate a compiled JavaScript file named index.js.

      After the compilation is successful, run the following command to execute the CLI:
      `node index.js`

      - The CLI will prompt you to enter the path to the log file. Provide the absolute or relative path to the log file you downloaded from the Google Drive link.

      - The CLI will then process the log data and display the requested insights in a formatted table.

         - **Endpoint Call Counts:** This section shows the number of calls made to each API endpoint.

         - **API Calls Per Minute:** This section displays the count of API calls made per minute.

         - **API Calls by Status Code:** This section provides a formatted table with status codes (200, 500, 404, 304) and their  corresponding counts. We have limited status codes to only four and can add more if needed.

## Log Data Format

The script expects the log data to be in the following format:

```
YYYY-MM-DD HH:mm +TZ: Log Message with Endpoint and Status Code
```

For example:

```
2023-06-08 15:48 +10:00: 2023-06-08 15:48:10 [32minfo[39m: a request has been made with the following uuid [a8a8e6cb-fb38-486c-b5d0-b978ebea4048] /localstart.asp curl/7.54.0 {}
2023-06-08 15:48 +10:00: ::ffff:172.105.184.153 - - [08/Jun/2023:05:48:10 +0000] "GET /localstart.asp HTTP/1.1" 404 153 "-" "curl/7.54.0"
...
```

## Customization

If you want to modify the allowed status codes or add more functionalities, you can edit the `allowedStatusCodes` array in the `countApiCallsByStatusCode` function.

```typescript
const allowedStatusCodes = [200, 500, 404, 304, /* Add more status codes here */];
```
