"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
// Import required modules
var fs = require("fs");
var readlineSync = require("readline-sync");
// Read the log file and parse log data into an array of LogEntry objects
function readLogFile(filePath) {
    var logData = fs.readFileSync(filePath, 'utf8');
    var lines = logData.split('\n');
    var logEntries = [];
    for (var _i = 0, lines_1 = lines; _i < lines_1.length; _i++) {
        var line = lines_1[_i];
        try {
            var parts = line.split(' ');
            var timestamp = parts[0] + ' ' + parts[1];
            var statusCode = parseInt(parts[parts.length - 2]);
            var endpoint = parts[7];
            logEntries.push({ timestamp: timestamp, endpoint: endpoint, statusCode: statusCode });
        }
        catch (error) {
            // Ignore invalid log entries
        }
    }
    return logEntries;
}
// Count the number of calls made to each API endpoint
function countEndpointCalls(logEntries) {
    var endpointCalls = {};
    for (var _i = 0, logEntries_1 = logEntries; _i < logEntries_1.length; _i++) {
        var entry = logEntries_1[_i];
        var endpoint = entry.endpoint;
        if (!endpointCalls[endpoint]) {
            endpointCalls[endpoint] = 0;
        }
        endpointCalls[endpoint]++;
    }
    return endpointCalls;
}
// Count the number of API calls made per minute
function countApiCallsPerMinute(logEntries) {
    var apiCallsPerMinute = {};
    for (var _i = 0, logEntries_2 = logEntries; _i < logEntries_2.length; _i++) {
        var entry = logEntries_2[_i];
        var timestamp = entry.timestamp;
        var minute = timestamp.split(':')[0];
        if (!apiCallsPerMinute[minute]) {
            apiCallsPerMinute[minute] = 0;
        }
        apiCallsPerMinute[minute]++;
    }
    return apiCallsPerMinute;
}
// Count the number of API calls for specific status codes (200, 500, 404, 304)
function countApiCallsByStatusCode(logEntries) {
    var allowedStatusCodes = [200, 500, 404, 304];
    var apiCallsByStatusCode = {};
    for (var _i = 0, logEntries_3 = logEntries; _i < logEntries_3.length; _i++) {
        var entry = logEntries_3[_i];
        var statusCode = entry.statusCode;
        if (allowedStatusCodes.includes(statusCode)) {
            if (!apiCallsByStatusCode[statusCode]) {
                apiCallsByStatusCode[statusCode] = 0;
            }
            apiCallsByStatusCode[statusCode]++;
        }
    }
    var apiCallsByStatusCodeList = [];
    for (var statusCode in apiCallsByStatusCode) {
        apiCallsByStatusCodeList.push({ statusCode: parseInt(statusCode), count: apiCallsByStatusCode[statusCode] });
    }
    return apiCallsByStatusCodeList;
}
// Print the formatted table with API response data
function printFormattedTable(data) {
    console.log('┌──────────────┬────────────┬───────┐');
    console.log('|   (index)    | statusCode | count |');
    console.log('├──────────────┼────────────┼───────┤');
    data.forEach(function (entry) {
        var statusText = entry.statusCode === 200 ? 'OK' : entry.statusCode === 500 ? 'Server Error' : entry.statusCode === 404 ? 'Not found' : entry.statusCode === 304 ? 'Not changed' : '';
        console.log("\u2502 ".concat(statusText.padEnd(12), " \u2502     ").concat(entry.statusCode, "      \u2502  ").concat(entry.count.toString().padStart(4), "  \u2502"));
    });
    console.log('└──────────────┴────────────┴───────┘');
}
// Main function that orchestrates the log analysis
function main() {
    var filePath = readlineSync.question('Enter the path to the log file: ');
    try {
        // Read log data from the file
        var logEntries = readLogFile(filePath);
        // Count endpoint calls and display in a table
        var endpointCalls = countEndpointCalls(logEntries);
        console.log('Endpoint Call Counts:');
        console.table(endpointCalls);
        // Count API calls per minute and display in a table
        var apiCallsPerMinute = countApiCallsPerMinute(logEntries);
        console.log('\nAPI Calls Per Minute:');
        console.table(apiCallsPerMinute);
        // Count API calls by status code and display in a formatted table
        var apiCallsByStatusCode = countApiCallsByStatusCode(logEntries);
        console.log('\nAPI Calls by Status Code:');
        printFormattedTable(apiCallsByStatusCode);
    }
    catch (error) {
        console.error('Error occurred:', error.message);
    }
}
// Call the main function to start the log analysis
main();
